﻿Public Class formLaporanPendapatanParkir
    Private Sub buttonTutup_Click(sender As Object, e As EventArgs) Handles buttonTutup.Click
        Me.Hide()
    End Sub
End Class