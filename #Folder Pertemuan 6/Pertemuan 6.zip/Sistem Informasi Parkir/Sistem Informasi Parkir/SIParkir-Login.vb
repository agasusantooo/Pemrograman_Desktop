﻿Public Class formLogin
    Private Sub buttonKeluar_Click(sender As Object, e As EventArgs) Handles buttonKeluar.Click
        Me.Close()
    End Sub
End Class
