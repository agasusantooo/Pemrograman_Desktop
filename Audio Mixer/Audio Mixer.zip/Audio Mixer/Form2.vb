﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnMinHour.Click

    End Sub
End Class